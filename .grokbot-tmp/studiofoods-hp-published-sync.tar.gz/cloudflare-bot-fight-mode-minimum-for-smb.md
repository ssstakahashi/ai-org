---
title: 機械アクセスのコストを上げる。Cloudflare Bot Fight Modeの最小導入
slug: cloudflare-bot-fight-mode-minimum-for-smb
publishedAt: 2026-09-19
status: published
destination: studiofoods_hp
category: セキュリティ
tags: Cloudflare, Bot Fight Mode, ボット対策, セキュリティ, 中小企業
thumbnailUrl: "https://ssstakahashi-storage.studiofoods.net/image/st-hp_blog/blog_021_bot_fight_mode.jpeg"
source: grokbot
id: blog_a6ccab56-a1c9-4ec3-a135-c666c6ab8cf0
createdAt: "2026-09-15 23:25:22"
updatedAt: "2026-09-19 12:08:14"
sourceUrl: "https://ai-org.s-takahashi-241.workers.dev/blog-drafts?destination=studiofoods_hp"
excerpt: 公開サイトに届く機械アクセスを、ルールを書かずに一段高くする。FreeプランのCloudflare Bot Fight Modeを中心に、誤検知時の注意とWAF・Accessとの役割分担をまとめました。
---

## 「ボット」は特別な攻撃だけではない

公開サイトには、人がブラウザで見るアクセス以外に、機械からのアクセスが日常的に届きます。

- フォームやログインURLを機械的に試す通信
- コンテンツを大量に収集するクローラ
- 負荷試験や監視を装った連打

全部が悪意とは限りませんが、アプリ側だけで受け止めると、サーバー負荷やログノイズが増え、本当に見るべき異常が埋もれやすくなります。入口で「明らかな自動アクセス」のコストを上げておくと、運用の余裕が残ります。

※本記事は防御設計の一般解説です。攻撃手順や回避方法は扱いません。

## Cloudflare Bot Fight Modeとは

Cloudflareの **Bot Fight Mode** は、ドメイン全体に対して既知のボットらしい通信を検出し、計算コストの高いチャレンジを返す、Freeプラン向けのシンプルな対策です。

公式（概要）: https://developers.cloudflare.com/bots/

公式（Freeプラン）: https://developers.cloudflare.com/bots/plans/free/

公式（有効化手順）: https://developers.cloudflare.com/bots/get-started/bot-fight-mode/

FreeプランのBot Fight Modeで公開されている要点は次のとおりです。

1. **対象**: クラウドホスティング由来の単純なボットやヘッドレスブラウザなど
2. **動作**: 検出した通信に対して計算コストの高いチャレンジを発行する（※具体的には、訪問者のブラウザ上でバックグラウンドで処理されるJavaScriptチャレンジやマネージドチャレンジなどが発行され、自動プログラムのアクセス負荷を跳ね上げる仕組みです）
3. **範囲**: ドメイン全体に適用（パス単位の細かい振り分けはできない）
4. **追加機能の例**: AIボットのブロック、`robots.txt` による指示など（プラン資料に記載）

有料寄りの **Super Bot Fight Mode** や、Enterpriseの **Bot Management** は、カテゴリ別の制御やスコアベースの細かいルールが必要になったときの上位選択肢です。まずはFreeのトグルから、という段階設計が現実的です。

## 中小企業が先に入れる最小ステップ

### 1. Bot Fight Mode をオンにする

ダッシュボードの Security Settings で Bot traffic を絞り込み、Bot Fight Mode を有効にします（公式手順どおり）。

ポイントは「ルールを何本も書かず、入口の自動アクセスにコストを乗せる」ことです。WAFのManaged Rulesやレート制限（別記事）と役割が重なりつつも、ボット検知専用のスイッチとして先に入れやすい位置づけです。

### 2. 有効化後は Security > Events を見る

Bot Fight Modeがチャレンジした通信は、Security > Events で Service が Bot Fight Mode と付く、と公式に案内されています。最初の数日は「何が増えたか」を眺め、問い合わせフォームや会員ページの体験が崩れていないかを確認します。

### 3. 誤検知が出たら、無理にスキップルールを足さない

重要な注意点が公式に明記されています。

- Bot Fight Modeは Ruleset Engine 上では動かないため、**WAF Custom Rules の Skip や Page Rules ではバイパスできない**
- 例外が必要なら **Super Bot Fight Mode** へ上げる、または一時的に機能をオフにする、IP Access rules で先に許可する、といった別ルートになる

出典: https://developers.cloudflare.com/bots/troubleshooting/false-positives/  
および https://developers.cloudflare.com/bots/get-started/bot-fight-mode/

自社で契約している外部死活監視サービス（Uptime監視等）や外部システムからのWebhook・API連携が誤検知によってブロックされる場合は、「スキップを足せば済む」と思わず、プランと例外設計を見直すのが安全です。

### 4. 攻撃が激しいときの「Under Attack」とは別物

急なレイヤ7の過負荷時には、ゾーン全体の **Under Attack mode**（追加のブラウザチェック）も選択肢になります。ただし公式は「攻撃中の最終手段のひとつ」「常時オン向けではない」と位置づけています。Bot Fight Modeの日常トグルと混同しないようにします。

公式: https://developers.cloudflare.com/fundamentals/reference/under-attack-mode/

## これまでのシリーズとの役割分担

- **Access / Zero Trust**: 管理画面など「見せたくない入口」を認証の向こうへ
- **WAF（Managed / Custom / レート制限）**: 怪しいHTTPパターンや連打をルールで抑える
- **Bot Fight Mode（本記事）**: ドメイン全体の自動アクセスにチャレンジをかけてコストを上げる

全部を同時に完璧にしなくて大丈夫です。公開サイトなら Bot Fight Mode → WAF最小セット、社内ツールなら Access、という順でも運用は回り始めます。

## まとめ

Cloudflare Bot Fight Modeは、Freeプランでも入れられる「ボットらしい通信へのチャレンジ」スイッチです。細かい例外は苦手ですが、入口の自動アクセスを最初に薄くする用途には向いています。誤検知や正規の自動連携があるなら、Skipでごまかすのではなく Super Bot Fight Mode など上位の制御へ進む判断材料にするとよいでしょう。

自社のWebサイトのセキュリティ設定やCloudflareの導入・運用設計でお困りの際は、[サービス一覧](https://www.studiofoods.net/services)や[お問い合わせ](https://www.studiofoods.net/contact)からお気軽にご相談ください。

出典（いずれもCloudflare公式ドキュメント）:
- https://developers.cloudflare.com/bots/
- https://developers.cloudflare.com/bots/plans/free/
- https://developers.cloudflare.com/bots/get-started/bot-fight-mode/
- https://developers.cloudflare.com/bots/troubleshooting/false-positives/
- https://developers.cloudflare.com/use-cases/solutions/stop-malicious-bots/
- https://developers.cloudflare.com/fundamentals/reference/under-attack-mode/
