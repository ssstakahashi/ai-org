---
title: 公開サイトを「危ないリクエスト」から守る。Cloudflare WAFの最小セット
slug: cloudflare-waf-minimum-for-smb
publishedAt: 2026-09-16
status: published
destination: studiofoods_hp
category: セキュリティ
tags: Cloudflare, WAF, Managed Rules, レート制限, セキュリティ, 中小企業
thumbnailUrl: "https://ssstakahashi-storage.studiofoods.net/image/st-hp_blog/blog_018_cloudflare_waf.jpeg"
source: grokbot
id: blog_d174e1ef-de43-4df4-9c39-5cdf31e1b8f9
createdAt: "2026-09-13 23:10:24"
updatedAt: "2026-09-16 12:21:58"
sourceUrl: "https://ai-org.s-takahashi-241.workers.dev/blog-drafts?destination=studiofoods_hp"
excerpt: 公開サイトやフォームに届く怪しいリクエストを、アプリの手前で減らす。Cloudflare WAFのManaged Rules・Custom Rules・レート制限から、中小企業が先に入れる最小セットをまとめました。
---

## Webアプリへの「怪しいリクエスト」は日常的に来る

公開しているホームページやフォーム、会員ページには、人間の訪問以外にもさまざまなリクエストが届きます。

- 管理画面やログインURLを機械的に探るアクセス
- 問い合わせフォームやAPIへの過剰な連打
- 既知の脆弱性を狙うパターンのリクエスト

サーバー本体やアプリのログイン画面だけで受け止めると、負荷や誤動作、アカウントへの不正試行が増えやすくなります。手前の入口で「明らかにおかしい通信」を減らせると、運用の負担はかなり下がります。

## Cloudflare WAFとは何か

Cloudflare WAF（Web Application Firewall）は、サイトやAPIに届くHTTPリクエストをルールで検査し、望ましくない通信を遮断・挑戦（チャレンジ）・記録する仕組みです。

公式ドキュメント（Overview）: https://developers.cloudflare.com/waf/

WAFの中でも、中小企業が最初に触ることが多い部品は次の3つです。

1. **Managed Rules（マネージドルール）**: Cloudflareが用意・更新する既知の攻撃パターン対策
2. **Custom Rules（カスタムルール）**: 自社のURLや条件に合わせたルール
3. **Rate limiting rules（レート制限）**: 一定時間あたりのリクエスト回数に上限を設ける

※本記事は防御設計の一般解説です。攻撃手順や回避方法は扱いません。

## まず入れる「最小セット」

全部を一度に完璧に組む必要はありません。まずは次の順で十分です。

### 1. Free Managed Ruleset を有効にする

Freeプランでも、影響が大きく広く悪用される脆弱性向けの **Cloudflare Free Managed Ruleset** を使えます。有料プランでは、より広い **Cloudflare Managed Ruleset** や OWASP Core Ruleset も利用できます。

出典: Managed Rules — https://developers.cloudflare.com/waf/managed-rules/

ポイントは「自分でシグネチャをメンテしなくてよい」ことです。ルールは定期的に更新される前提で、まずは既定のまま有効化し、誤検知が出たら個別に例外やアクション調整を検討する、という進め方が現実的です。

### 2. カスタムルールで「触られたくない場所」を手前で締める

Custom Rulesは、パスやホストなどの条件で通信を絞り込む自作ルールです。Freeでもゾーンあたり最大5本、Proで20本などプランにより上限があります（数値は改定されるため、最新のAvailability表を確認してください）。

出典: Custom rules — https://developers.cloudflare.com/waf/custom-rules/

中小企業でよく効く例（考え方のみ）:

- 管理画面やステージング用のパスへの一般アクセスを制限する
- 国やASNなど粗い条件で明らかに不要な流入を減らす（過度な国制限は正規顧客にも影響するので慎重に）
- 特定の異常なUser-Agentやパスパターンをチャレンジ／ブロックする

「アプリ側のBasic認証だけ」より、CDN手前で弾く方がオリジンへの到達そのものを減らせます。管理画面そのものをインターネットに晒したくない場合は、前回のAccess（Zero Trust）記事と組み合わせるとより安全です。

### 3. レート制限でログインやフォームの連打を抑える

Rate limiting rulesは、「同じ相手から短時間に何回も来る」通信に上限を置きます。ログインや問い合わせフォーム、公開APIの乱用抑止に向いています。Freeでもルールを1本使えます（プランにより本数・期間・フィールドが異なります）。

出典: Rate limiting rules — https://developers.cloudflare.com/waf/rate-limiting-rules/

設定のコツは「正規のピーク利用を潰さない」ことです。まずはログインやフォーム送信など、攻撃されやすいエンドポイントに狭い範囲で適用し、Security Eventsで様子を見てから広げるのが安全です。

## プラン別で押さえておく上限の目安

公式のAvailability表から、最初に意識しやすい数字だけ抜粋します（変更されうるため、導入時は必ず最新ドキュメントを確認してください）。

| 機能 | Freeの目安 | 補足 |
| --- | --- | --- |
| Managed Rules | Free Managed Ruleset | 有料プランでより広いマネージド／OWASPも利用可 |
| Custom rules | 最大5本 | Pro 20 / Business 100 など |
| Rate limiting | 1本 | 期間やカウント特性はプランで差がある |

出典:

- WAF Overview Availability — https://developers.cloudflare.com/waf/
- Custom rules Availability — https://developers.cloudflare.com/waf/custom-rules/
- Rate limiting Availability — https://developers.cloudflare.com/waf/rate-limiting-rules/

## 導入後に見るべき場所

ルールを入れたら終わりではなく、次を定期的に見ます。

- **Security Events / Security Analytics**: 何がブロック・チャレンジされたか
- 正規ユーザーからの誤検知（特に社内ツールや特殊なAPI）
- ログイン・フォームの成功率や問い合わせ到達数

誤検知が出た場合は、いきなり全面オフにせず、該当ルールの例外（skip）やアクション緩和から調整するのが基本です。

## Accessとの役割分担

前回のシリーズ記事では、Cloudflare Accessで「管理画面の入口そのものを認証付きにする」最小構成を紹介しました。

- **Access**: 「誰が入れるか」を手前で決める（社内・限定公開）
- **WAF**: 「どんなリクエストを通すか」を手前で検査する（公開サイト全般）

公開のコーポレートサイトやフォームにはWAF、社内管理画面やステージングにはAccess、という分け方がわかりやすいです。

## 今日からできるチェックリスト

1. Cloudflareダッシュボードで対象ゾーンのWAF／セキュリティ設定を開く
2. Free Managed Ruleset（または契約プランのManaged Rules）が有効か確認する
3. 管理画面パス向けのCustom Ruleを1本検討する
4. ログインまたは問い合わせフォームにRate limitingを1本入れる
5. 1週間はSecurity Eventsを見て、誤検知と正規トラフィックを見分ける

小さく始めて、ログを見ながら足していく。それが中小企業向けの現実的なWAF運用です。
